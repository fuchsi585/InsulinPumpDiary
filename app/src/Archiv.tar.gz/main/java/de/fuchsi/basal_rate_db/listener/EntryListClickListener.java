package de.fuchsi.basal_rate_db.listener;


import android.view.View;
import android.view.View.OnClickListener;

public class EntryListClickListener implements OnClickListener{
    private int position;
    private OnEntryListClickListener callback;


    public EntryListClickListener(OnEntryListClickListener callback, int pos) {
        position = pos;
        this.callback = callback;

    }

    @Override
    public void onClick(View v){
        callback.onEntryListClicked(v, position);
    }

    public interface OnEntryListClickListener{
        void onEntryListClicked(View aView, int position);
    }
}
