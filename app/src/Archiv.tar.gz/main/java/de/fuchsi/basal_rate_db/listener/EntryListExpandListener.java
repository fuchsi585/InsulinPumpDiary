package de.fuchsi.basal_rate_db.listener;

import android.view.View;
import android.view.View.OnLongClickListener;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;

/**
 * Created by ronny on 11.11.16.
 */

public class EntryListExpandListener implements OnChildClickListener {
    private int position;
    private OnEntryListExpandClickListener callback;


    public EntryListExpandListener(OnEntryListExpandClickListener callback, int pos) {
        position = pos;
        this.callback = callback;

    }

    @Override
    public boolean onChildClick(ExpandableListView parent, View v, int groupPosition,int childPosition, long id){
        callback.onEntryListChildClicked(v, groupPosition);
        return true;
    }

    public interface OnEntryListExpandClickListener{
        void onEntryListChildClicked(View aView, int position);
    }
}
