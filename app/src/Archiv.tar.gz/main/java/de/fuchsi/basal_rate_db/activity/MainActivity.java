package de.fuchsi.basal_rate_db.activity;

import de.fuchsi.basal_rate_db.R;
import de.fuchsi.basal_rate_db.adapter.EntryListBaseAdapter;
import de.fuchsi.basal_rate_db.database.Entry;
import de.fuchsi.basal_rate_db.database.EntryDataSource;
import de.fuchsi.basal_rate_db.listener.EntryListClickListener.OnEntryListClickListener;
import de.fuchsi.basal_rate_db.listener.EntryListExpandListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.ExpandableListView;
import android.widget.ListView;

import java.util.List;


public class MainActivity extends AppCompatActivity implements EntryListExpandListener.OnEntryListExpandClickListener {
    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    public EntryDataSource dataSource;
    private List<Entry> entries;
    public EntryListBaseAdapter mListAdapter;

    ExpandableListView entryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dataSource = new EntryDataSource(this);
        dataSource.open();
        entries = dataSource.getAllEntries();
        entryList = (ExpandableListView) findViewById(R.id.entryList);
        mListAdapter = new EntryListBaseAdapter(getApplicationContext(), entries,this);
        entryList.setAdapter(mListAdapter);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(new Intent(view.getContext(), AddNewEntryActivity.class),1);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        Bundle b;
        Entry intentData;

        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                b = data.getExtras();
                if (data.hasExtra(Entry.NEW) && (b != null)) {
                    intentData = (Entry) b.getSerializable(Entry.NEW);
                    if (intentData != null) {
                        Log.d(LOG_TAG, "Create Entry!");
                        dataSource.createEntry(intentData.getName(), intentData.getBasalRateArrayString(), intentData.getActive());
                    }
                    refreshList();
                }
            } else if (requestCode == 2) {
                b = data.getExtras();
                if (data.hasExtra(Entry.UPDATE) && (b != null)) {
                    intentData = (Entry) b.getSerializable(Entry.UPDATE);
                    if (intentData != null) {
                        Log.d(LOG_TAG, "Update Entry!");
                        dataSource.updateEntry(intentData);
                    }
                }
                else if (data.hasExtra(Entry.DELETE) && (b != null)){
                    Log.d(LOG_TAG, "Delete Entry!");
                    dataSource.deleteEntry(b.getString(Entry.DELETE));
                }
                refreshList();
            }
        }

    }

    public void onEntryListChildClicked(View aView, int position) {
        //Entry editEntry = mListAdapter.getItem(position);
        Entry editEntry = (Entry) mListAdapter.getGroup(position);
        Intent editActivity = new Intent(this, AddNewEntryActivity.class);
        editActivity.putExtra(Entry.UPDATE, editEntry);
        startActivityForResult(editActivity,2);
    }

    /*@Override
    public void onEntryListClicked(View aView, int position) {
        //Entry editEntry = mListAdapter.getItem(position);
        Entry editEntry = (Entry) mListAdapter.getGroup(position);
        Intent editActivity = new Intent(this, AddNewEntryActivity.class);
        editActivity.putExtra(Entry.UPDATE, editEntry);
        startActivityForResult(editActivity,2);
    }*/
    /*@Override
    public void onEntryListPressAndHold(View aView, int position){

    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_sort) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        else if(id == R.id.action_about){
            startActivity(new Intent(this, AboutActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void refreshList(){
        entries = dataSource.getAllEntries();
        mListAdapter.updateAdapter(entries);
    }
}
