package de.fuchsi.basal_rate_db.listener;


import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupClickListener;

public class EntryListHeaderClickListener implements OnGroupClickListener{
    private int position;
    private OnEntryListHeaderClickListener callback;

    public EntryListHeaderClickListener(OnEntryListHeaderClickListener callback, int pos) {
        position = pos;
        this.callback = callback;
    }

    @Override
    public void onGroupCicked(ExpandableListView parent, View v, int groupPosition,int childPosition, long id){
        callback.onEntryHeaderClicked(v, position);
    }

    public interface OnEntryListHeaderClickListener{
        void onEntryHeaderClicked(View aView, int position);
    }
}
