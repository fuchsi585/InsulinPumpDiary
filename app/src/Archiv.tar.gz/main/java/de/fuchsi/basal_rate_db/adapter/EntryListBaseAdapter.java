package de.fuchsi.basal_rate_db.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.List;
import java.util.Objects;

import de.fuchsi.basal_rate_db.R;
import de.fuchsi.basal_rate_db.database.Entry;
//import de.fuchsi.basal_rate_db.listener.EntryListClickListener;
//import de.fuchsi.basal_rate_db.listener.EntryListClickListener.OnEntryListClickListener;
import de.fuchsi.basal_rate_db.listener.EntryListClickListener;

import de.fuchsi.basal_rate_db.listener.EntryListExpandListener;
import de.fuchsi.basal_rate_db.listener.EntryListExpandListener.OnEntryListExpandClickListener;
import de.fuchsi.basal_rate_db.views.GraphView;

/**
 * Created by ronny on 10.11.16.
 */

public class EntryListBaseAdapter extends BaseExpandableListAdapter {

    private final LayoutInflater mInflater;
    private OnEntryListExpandClickListener mClickListener;
    private List<Entry> mModel;


    public EntryListBaseAdapter(Context context, List<Entry> model,
                                OnEntryListExpandClickListener callback){
        mInflater = LayoutInflater.from(context);
        this.mModel = model;
        this.mClickListener = callback;
    }
    @Override
    public int getGroupCount() {
        return mModel.size();
    }
    @Override
    public double[] getChild(int groupPos, int childPos) {
        return this.mModel.get(groupPos).getBasalRateArray();
    }
    @Override
    public long getChildId(int groupPos, int childPos) {
        return childPos;
    }
    @Override
    public View getChildView(int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        double[] childData = getChild(groupPosition, childPosition);

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.list_item_expandable, parent, false);
            convertView.setBackgroundColor(Color.WHITE);
        }
        GraphView graphView = (GraphView) convertView.findViewById(R.id.item_graphView);

        graphView.initializeData(childData);
        return convertView;
    }
    @Override
    public Object getGroup(int groupPosition) {
        return mModel.get(groupPosition);
    }
    @Override
    public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        //String itemTitle = getGroup(groupPosition);

        if (convertView == null){
            convertView = mInflater.inflate(R.layout.list_item_header, parent, false);
            convertView.setBackgroundColor(Color.WHITE);
        }
        TextView title = (TextView) convertView.findViewById(R.id.item_title);
        TextView total = (TextView) convertView.findViewById(R.id.item_total);
        Entry mEntry = (Entry) getGroup(groupPosition);
        title.setText(mEntry.getName());
        total.setText("24-Total: " + String.valueOf(mEntry.getBasalRateSum()) + " Units");

        ExpandableListView list = (ExpandableListView) parent;
        list.setOnChildClickListener(new EntryListExpandListener(mClickListener, groupPosition));
        list.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView expandableListView, View view, int i, long l) {
                if (expandableListView.isGroupExpanded(i)) expandableListView.collapseGroup(i);
                else expandableListView.expandGroup(i);

                return true;
            }
        });
        //list.expandGroup(groupPosition);
        return convertView;
    }

    /*@Override
    public int getCount() {
        return mModel.size();
    }
    @Override
    public Entry getItem(int position) {
        return mModel.get(position);
    }
    @Override
    public long getItemId(int position) {
        return (long) position;
    }*/

    public void updateAdapter(List<Entry> entries){
        mModel = entries;
        notifyDataSetChanged();
    }
    /*
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null){
            convertView = mInflater.inflate(R.layout.list_item_header, parent, false);
            //convertView.setBackgroundColor(Color.WHITE);
            holder = new ViewHolder();
            holder.title = (TextView) convertView.findViewById(R.id.item_title);
            holder.total = (TextView) convertView.findViewById(R.id.item_total);
            convertView.setTag(holder);
        }//else {

        //}
        holder = (ViewHolder) convertView.getTag();

        Entry mEntry = getItem(position);
        holder.title.setText(mEntry.getName());
        holder.total.setText("24-Total: " + String.valueOf(mEntry.getBasalRateSum()) + " Units");

        convertView.setOnClickListener(new EntryListClickListener(mClickListener,position));

        return convertView;
    }*/
    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
    @Override
    public boolean hasStableIds() {
        return false;
    }
    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }
    @Override
    public int getChildrenCount(int groupPosition) {
        return 1;
    }

    public static class ViewHolder{
        TextView title;
        TextView total;

        public ViewHolder(){

        }
    }
}
